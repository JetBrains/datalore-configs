{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "datalore.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "datalore.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "datalore.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "datalore.labels" -}}
helm.sh/chart: {{ include "datalore.chart" . }}
{{ include "datalore.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "datalore.selectorLabels" -}}
app.kubernetes.io/name: {{ include "datalore.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "datalore.serviceAccountName" -}}
{{- default (include "datalore.fullname" .) .Values.serviceAccount.name }}
{{- end }}

{{/*
Create the name of the database secret to use
*/}}
{{- define "datalore.databaseSecretName" -}}
{{- default (printf "%s-db" (include "datalore.fullname" .)) .Values.databaseSecret.name }}
{{- end }}

{{- define "datalore.serverImage.version" -}}
{{- if .Values.serverImage.versionOverride }}
{{- .Values.serverImage.versionOverride }}
{{- else }}
{{- .Values.dataloreVersion | default .Chart.AppVersion }}
{{- end }}
{{- end }}
{{- define "datalore.databaseCommandImage.version" -}}
{{- if .Values.databaseCommandImage.versionOverride }}
{{- .Values.databaseCommandImage.versionOverride }}
{{- else }}
{{- .Values.dataloreVersion | default .Chart.AppVersion }}
{{- end }}
{{- end }}
{{- define "datalore.gitTaskImage.version" -}}
{{- if .Values.gitTaskImage.versionOverride }}
{{- .Values.gitTaskImage.versionOverride }}
{{- else }}
{{- .Values.dataloreVersion | default .Chart.AppVersion }}
{{- end }}
{{- end }}
{{- define "datalore.agentImage.version" -}}
{{- if .Values.agentImage.versionOverride }}
{{- .Values.agentImage.versionOverride }}
{{- else }}
{{- .Values.dataloreVersion | default .Chart.AppVersion }}
{{- end }}
{{- end }}
{{- define "datalore.sidecarImage.version" -}}
{{- if .Values.sidecarImage.versionOverride }}
{{- .Values.sidecarImage.versionOverride }}
{{- else }}
{{- .Values.dataloreVersion | default .Chart.AppVersion }}
{{- end }}
{{- end }}
{{- define "datalore.authProxyImage.version" -}}
{{- if .Values.authProxyImage.versionOverride }}
{{- .Values.authProxyImage.versionOverride }}
{{- else }}
{{- .Values.dataloreVersion | default .Chart.AppVersion }}
{{- end }}
{{- end }}
{{- define "datalore.agentNetworkNamespaceImage.version" -}}
{{- if .Values.agentNetworkNamespaceImage.versionOverride }}
{{- .Values.agentNetworkNamespaceImage.versionOverride }}
{{- else }}
{{- .Values.dataloreVersion | default .Chart.AppVersion }}
{{- end }}
{{- end }}

{{/*
Create the image repository to use for each component.
The per-component repository wins when set; otherwise it is imageRegistry with the
component name appended.
*/}}
{{- define "datalore.serverImage.repository" -}}
{{- .Values.serverImage.repository | default (printf "%s/datalore-server" .Values.imageRegistry) }}
{{- end }}
{{- define "datalore.postgresImage.repository" -}}
{{- .Values.postgresImage.repository | default (printf "%s/datalore-postgres" .Values.imageRegistry) }}
{{- end }}
{{- define "datalore.databaseCommandImage.repository" -}}
{{- .Values.databaseCommandImage.repository | default (printf "%s/datalore-database-command" .Values.imageRegistry) }}
{{- end }}
{{- define "datalore.gitTaskImage.repository" -}}
{{- .Values.gitTaskImage.repository | default (printf "%s/datalore-git-task" .Values.imageRegistry) }}
{{- end }}
{{- define "datalore.agentImage.repository" -}}
{{- .Values.agentImage.repository | default (printf "%s/datalore-agent" .Values.imageRegistry) }}
{{- end }}
{{- define "datalore.sidecarImage.repository" -}}
{{- .Values.sidecarImage.repository | default (printf "%s/datalore-sidecar-mounter" .Values.imageRegistry) }}
{{- end }}
{{- define "datalore.authProxyImage.repository" -}}
{{- .Values.authProxyImage.repository | default (printf "%s/datalore-auth-proxy" .Values.imageRegistry) }}
{{- end }}
{{- define "datalore.agentNetworkNamespaceImage.repository" -}}
{{- .Values.agentNetworkNamespaceImage.repository | default (printf "%s/datalore-agent-network-namespace" .Values.imageRegistry) }}
{{- end }}
